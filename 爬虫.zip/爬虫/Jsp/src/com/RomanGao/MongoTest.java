package com.baizhi;

import static org.junit.Assert.*;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;

public class MongoTest {
	private static Mongo mongo;
	private static DB db;
	private static DBCollection dbCollection;
	static{
		try {
			mongo = new Mongo("localhost",27017);
			db = mongo.getDB("users");
			dbCollection = db.getCollection("admin");
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * ��ѯ����
	 */
	@Test
	public void test() {
		DBCursor find = dbCollection.find();
		for (DBObject dbObject : find) {
			System.out.println(dbObject);
		}
	}
	/**
	 * ������ѯ
	 */
	@Test
	public void test1(){
		BasicDBObject basicDBObject = new BasicDBObject();
		BasicDBObject basicDBObject2 = new BasicDBObject();
		basicDBObject2.put("$gt", 11);
		basicDBObject.put("age",basicDBObject2);
		//DBObject findOne = dbCollection.findOne(basicDBObject);
		DBCursor find = dbCollection.find(basicDBObject);
		for (DBObject dbObject : find) {
			System.out.println(dbObject);
		}
	}
	/**
	 * ģ����ѯ��ѯ
	 */
	@Test
	public void test2(){
		BasicDBObject basicDBObject = new BasicDBObject();
		BasicDBObject basicDBObject1 = new BasicDBObject();
		basicDBObject1.put("$regex", "ba");
		basicDBObject.put("name",basicDBObject1);
		//DBObject findOne = dbCollection.findOne(basicDBObject);
		DBCursor find = dbCollection.find(basicDBObject);
		for (DBObject dbObject : find) {
			System.out.println(dbObject);
		}
	}
	/**
	 * ���뼯��
	 */
	@Test
	public void test3(){
		BasicDBObject basicDBObject1 = new BasicDBObject();
		BasicDBObject basicDBObject2 = new BasicDBObject();
		BasicDBObject basicDBObject3 = new BasicDBObject();
		basicDBObject1.put("name","ddd");
		basicDBObject1.put("age",18);
		basicDBObject2.put("name","eee");
		basicDBObject2.put("age",22);
		basicDBObject3.put("name","fff");
		basicDBObject3.put("age",26);
		List<BasicDBObject> list = new ArrayList<BasicDBObject>();
		list.add(basicDBObject1);
		list.add(basicDBObject2);
		list.add(basicDBObject3);
		BasicDBObject basicDBObject4 = new BasicDBObject();
		basicDBObject4.put("list", list);
		//DBObject findOne = dbCollection.findOne(basicDBObject);
		dbCollection.save(basicDBObject4);
	}
	/**
	 * �޸�
	 */
	@Test
	public void test4(){
		BasicDBObject basicDBObject1 = new BasicDBObject();
		basicDBObject1.put("name", "aaa");
		BasicDBObject basicDBObject2 = new BasicDBObject();
		basicDBObject2.put("age",100);
		BasicDBObject basicDBObject3 = new BasicDBObject();
		basicDBObject3.put("$set",basicDBObject2);
		dbCollection.update(basicDBObject1, basicDBObject3, false, false);
	}
}
