package com.baizhi;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Servlet extends HttpServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Student stu = new Student();
		stu.setAge(18);
		stu.setName("С��");
		Student stu1 = new Student();
		stu1.setAge(11);
		stu1.setName("С��");
		Student stu2 = new Student();
		stu2.setAge(12);
		stu2.setName("С��");
		ArrayList arrayList = new ArrayList();
		arrayList.add(stu);
		arrayList.add(stu1);
		arrayList.add(stu2);
		request.setAttribute("st1", stu);
		request.setAttribute("lsit", arrayList);
		HttpSession session = request.getSession();
		session.setAttribute("st2",stu);
		ServletContext servletContext = getServletContext();
		servletContext.setAttribute("st3",stu);
		ServletConfig servletConfig = getServletConfig();
		System.out.println(servletConfig.getServletName());
		request.getRequestDispatcher("one.jsp?name=five&age=100").forward(request, response);
		
	}
}
