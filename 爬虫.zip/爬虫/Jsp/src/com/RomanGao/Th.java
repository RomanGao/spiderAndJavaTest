package com.baizhi;

public class Th implements Runnable{
	 int  ticket = 100;
	 float a = 11;
	@Override
	public  void run() {
		// TODO Auto-generated method stub
		while(true){
			if(ticket==0){
				break;
			}
			synchronized(this){
				ticket--;
			}
				System.out.println("��ʣ"+ticket+"��Ʊ");
				
				
			}
		
	}
}
