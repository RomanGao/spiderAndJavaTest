package com.baizhi;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.sun.swing.internal.plaf.basic.resources.basic;

public class Crawler {
	public static void main(String[] args) throws Exception {
		Document document = Jsoup.connect("http://bj.ganji.com/zpshichangyingxiao/").get();
		Elements select = document.select("a[class=list_title gj_tongji]");
		for (Element element : select) {
			System.out.println(element.attr("href"));
		}
	}
	
	public static void saveImg(String url) throws Exception{
		URL url2 = new URL(url);
		URLConnection openConnection = url2.openConnection();
		InputStream inputStream = openConnection.getInputStream();
		BufferedInputStream buff= new BufferedInputStream(inputStream);
		FileOutputStream fileOutputStream = new FileOutputStream(new File("f://img//iphone.jpg"));
		byte[] by =new byte[1024];
		int i = 0;
		while((i=buff.read(by))!=-1){
			fileOutputStream.write(by, 0, i);
		}
		inputStream.close();
		fileOutputStream.close();
		buff.close();
	}
}

